# JDesktopPane-Sample
A simple java project that shows how to use JDialog, JDesktopPane and JInternalFrame.
